﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week9_10
{
    public class Reader
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int readerId { get; set; }

        [StringLength(100)]
        [Required]
        public string name { get; set; }

        [StringLength(100)]
        [Required]
        public string email { get; set; }

        
        public virtual ICollection<Book> books { get; set; }

        public Reader()
        {
            books = new HashSet<Book>();
        }
    }
}



