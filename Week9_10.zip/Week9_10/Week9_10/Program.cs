﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System.Xml.Linq;
using Week9_10;

public class Program
{
    public static void Main(string[] args)
    {   
        
        ReadersDbContext context = new ReadersDbContext();

        
        string json = File.ReadAllText("readers.json");
        
        var libraryData = JsonConvert.DeserializeObject<LibraryData>(json);


        

        if (libraryData?.Readers != null)
        {
            
            context.Readers.AddRange(libraryData.Readers);
            context.Books.AddRange(libraryData.Books);
            context.SaveChanges();
        }

        Queries(context);
        
    }

    public static void Queries(ReadersDbContext context)
    {
        // 1. Olvasó, aki a legtöbb könyvet kölcsönözte
        var topReader = context.Readers.Include(t => t.books)
            .OrderByDescending(r => r.books.Count)
            .FirstOrDefault();
        Console.WriteLine($"A legtöbb könyvet kölcsönözte: {topReader?.name}");

        // 2. Legkorábban kölcsönzött könyv és olvasója
        var earliestBorrowedBook = context.Books
            .Where(b => b.borrowedDate != null)
            .OrderBy(b => b.borrowedDate)
            .Select(b => new { b.title, b.reader.name })
            .FirstOrDefault();
        Console.WriteLine($"A legkorábban kölcsönzött könyv: {earliestBorrowedBook?.title}, Olvasó: {earliestBorrowedBook?.name}");

        // 3. Olvasók és az általuk kölcsönzött könyvek, rendezve
        var readersWithBooks = context.Readers
            .OrderBy(r => r.name)
            .Select(r => new { r.name, BookTitles = r.books.Select(b => b.title).ToList() });
        foreach (var reader in readersWithBooks)
        {
            Console.WriteLine($"{reader.name}: {string.Join(", ", reader.BookTitles)}");
        }

        // 4. Havi kölcsönzések száma
        int month = DateTime.Now.Month;
        int year = DateTime.Now.Year;
        var monthlyBorrows = context.Books
            .Count(b => b.borrowedDate.HasValue && b.borrowedDate.Value.Month == month && b.borrowedDate.Value.Year == year);
        Console.WriteLine($"Kölcsönzések száma ebben a hónapban: {monthlyBorrows}");

        // 5. Adott szerzőtől kölcsönzött könyvek olvasói
        string authorName = "Jane Smith";
        var readersOfAuthor = context.Readers
            .Where(r => r.books.Any(b => b.author == authorName))
            .Select(r => r.name);
        Console.WriteLine($"Olvasók, akik {authorName} könyveit kölcsönözték: {string.Join(", ", readersOfAuthor)}");

        // 6. Olvasók, akiknél több mint 3 könyv van
        var readersWithManyBooks = context.Readers
            .Where(r => r.books.Count > 3)
            .Select(r => r.name);
        Console.WriteLine("Olvasók, akiknél több mint 3 könyv van: " + string.Join(", ", readersWithManyBooks));

        //7.Teljes kölcsönzési díj kiszámítása és tárolása
        double dailyFee = 100; // napi díj

        
        var readerFees = context.Readers
            .AsEnumerable() 
            .Select(r => new
            {
                r.name,
                TotalFee = r.books
                    .Where(b => b.borrowedDate.HasValue)
                    .Sum(b => (DateTime.Now - b.borrowedDate.Value).Days * dailyFee)
            });
        
        foreach (var readerFee in readerFees)
        {
            Console.WriteLine($"{readerFee.name}: {readerFee.TotalFee} HUF");
        }

        

        context.SaveChanges();



        //8. Kölcsönzések csoportosítása hónapok szerint, mentés XML formátumban
        var monthlyBorrowsGrouped = context.Books
             .Where(b => b.borrowedDate.HasValue)
             .GroupBy(b => new { b.borrowedDate.Value.Year, b.borrowedDate.Value.Month })
             .Select(g => new
             {
                 Year = g.Key.Year,
                 Month = g.Key.Month,
                 BorrowCount = g.Count()
             })
             .ToList();

        // XML dokumentum létrehozása és mentése
        XDocument document = new XDocument();
        var root = new XElement("MonthlyBorrows");
        document.Add(root);

        root.Add(monthlyBorrowsGrouped);


        document.Save("monthlyBorrows.xml");
        Console.WriteLine($"XML file saved at monthlyBorrows.xml");
    }

}

public class LibraryData
{
    public List<Reader> Readers;
    public List<Book> Books;
}

public class MinBorrowAttribute : Attribute
{
    public MinBorrowAttribute(int minBorrow)
    {
        this.minBorrow = minBorrow;
    }

    public int minBorrow { get; set; }

    
}

